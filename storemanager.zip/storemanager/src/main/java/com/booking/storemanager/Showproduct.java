/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booking.storemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ABHAY
 */
public class Showproduct {
    public static String getTname(String pname){
        String name="";
        try{
            Connection conn=Database.getConnection();
            PreparedStatement st=conn.prepareStatement("SELECT pname FROM products ;");
            st.setString(1, pname);
            ResultSet rs=st.executeQuery();
            rs.next();
            name = rs.getString("pname");
        }catch(Exception e){
            e.printStackTrace();
        }
        return name;
    }
    
    public static int getproduct(String pname){
        int id=0;
        try{
            Connection conn=Database.getConnection();
            PreparedStatement st=conn.prepareStatement("SELECT pid FROM products where pname=?;");
            st.setString(1, pname);
            ResultSet rs=st.executeQuery();
            rs.next();
            id=rs.getInt("pid");
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return id;
    }
    
}
