/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booking.storemanager;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author ABHAY
 */
public class userdb {
    public static String presentid;
    public static boolean validate(String name,String password){
        boolean status=false;
            try {
                Connection con = Database.getConnection();
                PreparedStatement ps=con.prepareStatement("select * from user where username=? and pswd=?");
                ps.setString(1,name);
                ps.setString(2,password);
                ResultSet rs=ps.executeQuery();
                status=rs.next();
            presentid = rs.getString("username");
            }catch(Exception e){System.out.println(e);}
        return status;
    }
    public static boolean pvalidate(String name,String password){
        boolean status=false;
            try {
                Connection con = Database.getConnection();
                PreparedStatement ps=con.prepareStatement("select * from producer where name=? and password=?");
                ps.setString(1,name);
                ps.setString(2,password);
                ResultSet rs=ps.executeQuery();
                status=rs.next();
            presentid = rs.getString("name");
            System.out.println(presentid);
            }catch(Exception e){System.out.println(e);}
        return status;
    }
    
    public static int add(String uname,String pswd){
        int status=0;
	try{
            Connection con = Database.getConnection();
            String sql="INSERT INTO theatresystem.user(username,pswd) VALUES(?,?);";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,uname);
            ps.setString(2,pswd);
            status = ps.executeUpdate();
            con.close();
	}catch(Exception e){
            System.out.println(e);
        }
        return status;
    }
    public static int add1(String uname,String pswd,String email,String no){
        int status=0;
	try{
            Connection con = Database.getConnection();
            String sql="INSERT INTO theatresystem.producer(name,password,email,phone) VALUES(?,?,?,?);";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,uname);
            ps.setString(2,pswd);
            ps.setString(3,email);
            ps.setString(4,no);
            status = ps.executeUpdate();
            con.close();
	}catch(Exception e){
            System.out.println(e);
        }
        return status;
    }
}
