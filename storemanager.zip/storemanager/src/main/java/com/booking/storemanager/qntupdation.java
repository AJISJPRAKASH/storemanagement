/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.booking.storemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ABHAY
 */
public class qntupdation {
    public static boolean available(String pnam,Float qnty)
    {int status=1;
        try {
            
            try {
                Connection con=Database.getConnection();
                PreparedStatement ps=con.prepareStatement("UPDATE products SET qnt=qnt-? WHERE pname=?;");
                ps.setFloat(1,qnty);
                ps.setString(2,pnam);
                System.out.println(qnty);
                System.out.println(pnam);
                ps.executeUpdate();
            }catch(Exception e){
                System.out.println("EEEEEEEEE");
                status=0;
            }
            Connection con=Database.getConnection();
            PreparedStatement ps=con.prepareStatement("delete from products WHERE qnt=0;");
            ps.executeUpdate();
        }catch(SQLException ex){
                Logger.getLogger(qntupdation.class.getName()).log(Level.SEVERE, null, ex);
            }
        if(status==0)
                return false;
            else
                return true;
    }
    
}
